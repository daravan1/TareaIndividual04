import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  plants: any[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit() {
    this.loadPlants();
  }

  loadPlants() {
    this.apiService.getPlants().subscribe({
      next: (response: any) => {
        this.plants = response.plants;
      },
      error: (error) => {
        console.error('Error loading plants:', error);
      }
    });
  }

  editPlant(id: number) {
    console.log('Edit plant:', id);
  }

  deletePlant(id: number) {
    console.log('Delete plant:', id);
    // ya no se
  }
}