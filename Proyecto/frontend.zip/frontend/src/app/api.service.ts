import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

// Exporta la interfaz Plant
export interface Plant {
  common_name: string;
  species: string;
  conservation_status: string;
  registered_by: string;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) { }

  getPlants(): Observable<{plants: Plant[]}> {
    return this.http.get<{plants: Plant[]}>(`${this.apiUrl}/plants/`);
  }
}