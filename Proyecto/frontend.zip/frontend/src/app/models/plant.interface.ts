export interface Plant {
    id: number;
    common_name: string;
    species: string;
    conservation_status: string;
    registered_by: string;
}